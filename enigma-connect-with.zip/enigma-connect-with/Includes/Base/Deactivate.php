<?php

/**
 *
 * This class defines all paths during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Enigma_Connect_With
 * @subpackage Enigma_ChrisIncludes/Base
 * @author     Christian <nwachukwu16@gmail.com>
 */

 namespace Inc\Base;

class Deactivate
{

	public static function deactivate() {

    //Delete the option colors
    delete_option( 'enigma_facebook_color' );
    delete_option( 'enigma_twitter_color' );
    delete_option( 'enigma_linkedin_color' );
    delete_option( 'enigma_instagram_color' );
    delete_option( 'enigma_google_plus_color' );
    delete_option( 'enigma_pinterest_color' );
    delete_option( 'enigma_flicker_color' );
    delete_option( 'enigma_youtube_color' );
    delete_option( 'enigma_title_color' );

    //delete the sizes
    delete_option( 'enigma_icon_size' );
    delete_option( 'enigma_title_size' );

    //Delete the social urls
    delete_option( 'enigma_facebook_url' );
    delete_option( 'enigma_twitter_url' );
    delete_option( 'enigma_linkedin_url' );
    delete_option( 'enigma_instagram_url' );
    delete_option( 'enigma_google_plus_url' );
    delete_option( 'enigma_pinterest_url' );
    delete_option( 'enigma_flicker_url' );
    delete_option( 'enigma_youtube_url' );
    delete_option( 'enigma_title_url' );


		flush_rewrite_rules();
	}
  

}
